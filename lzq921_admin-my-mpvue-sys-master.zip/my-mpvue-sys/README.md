# mpvue-sys

mpvue项目

# mpvue快速入门：
http://mpvue.com/mpvue/quickstart/

# weui：原版weui
http://jqweui.com/components

# mpvue-weui： 用 vue 写小程序，使用 mpvue 框架重写 WeUI。
https://youzan.github.io/vant-weapp/#/quickstart

# vant：Vant Weapp 是有赞移动端组件库 Vant 的小程序版本
https://youzan.github.io/vant-weapp/#/quickstart

> A Mpvue project

## 新环境项目创建 Setup


``` bash

# 1安装 nodejs 环境
现代前端开发框架和环境都是需要 Node.js 的，如果没有的话，请先下载 nodejs 并安装。

# 2打开项目后切换项目根目录install环境
npm install

# 3编译调试 （serve with hot reload at localhost:8080）
npm run dev

# 编译 （build for production with minification）
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```
